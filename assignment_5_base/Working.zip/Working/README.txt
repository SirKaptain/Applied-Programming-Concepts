STEPS:
1) Run database_setup.py ONCE to create test tables.
2) Run main.py for execution of the program.